# SkillSprout — LearnLoop

A responsive learning-roadmap app for engineering students. It is built around the SkillSprout hackathon brief.

## Features
- Student diagnostic intake: branch, semester, coding familiarity, career goal and weekly study hours.
- 40-course catalog with searchable codes, tags, credits, levels and prerequisites.
- Prerequisite-aware roadmap generated using Kahn's topological-sort algorithm (cycle detection included in the API).
- Course enrollment and completion tracking with browser `localStorage` persistence.
- Progress dashboard, earned-credit totals and next-step suggestions.
- Weekly study-hours target, sample peer-study groups and roadmap export.
- Responsive layout for desktop, tablet and mobile.

## Tech stack
React + Vite, Express, Lucide icons, CSS, and localStorage. The frontend works without an account or external database. The Express API exposes `/api/health`, `/api/courses`, `/api/tracks`, and `POST /api/roadmap`.

## Run locally
Requires Node.js 18+.

```bash
npm install
npm run dev
```
Open the Vite URL printed in the terminal (usually http://localhost:5173). The API runs at http://localhost:4000.

## Production build
```bash
npm run build
npm start
```
Then open http://localhost:4000.

## Data and demo notes
The 40 course entries are illustrative, syllabus-inspired sample data; verify course codes, credits and prerequisites against your university's official curriculum before academic use. Student data is saved only in the current browser. Study groups are demo recommendations, not live matching.

## Project structure
```text
client/src/       React application, course catalog and styles
server/           Express API and roadmap endpoint
index.html        Vite entry point
```

## GitHub
See `GITHUB_SETUP.md` for beginner-friendly upload steps.
