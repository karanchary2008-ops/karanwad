# Push SkillSprout to GitHub (beginner steps)

## Method 1 — GitHub website (easiest)
1. Sign in at https://github.com.
2. Click **New** (or the **+** menu → **New repository**).
3. Enter `skillsprout-learnloop` as the repository name.
4. Choose **Public** or **Private**, then click **Create repository**. Do not add a README (this ZIP already has one).
5. Extract the ZIP on your computer.
6. On the new repository page, choose **uploading an existing file**.
7. Open the extracted `skillsprout-learnloop` folder and drag its files and folders into the GitHub upload area. Upload the *contents* of the folder, not the ZIP itself.
8. Wait for upload, enter commit message `Add SkillSprout LearnLoop project`, and click **Commit changes**.

## Method 2 — Git command line
Install Git from https://git-scm.com/downloads, then open Terminal / PowerShell inside the extracted project folder.

```bash
git init
git add .
git commit -m "Add SkillSprout LearnLoop project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/skillsprout-learnloop.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. If Git asks you to sign in, complete the browser authentication.

## Run the project before uploading
Install Node.js 18+ from https://nodejs.org, open a terminal in the project folder and run:

```bash
npm install
npm run dev
```

Open the local URL Vite prints (normally http://localhost:5173). Stop the server with `Ctrl + C`.

**Tip:** Never upload passwords, API keys or `.env` files. The included `.gitignore` excludes common generated and secret files.
